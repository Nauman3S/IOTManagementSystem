rm -rf package-lock.json
npm install && npm cache clean --force
