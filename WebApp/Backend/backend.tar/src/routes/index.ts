export { default as authRoutes } from "./auth.routes";
export { default as macAddressRoutes } from "./macAddress.routes";
export { default as mqttRoutes } from "./mqtt.routes";
export { default as adminRoutes } from "./admin.routes";
export { default as countRoutes } from "./count.routes";
export { default as scriptRoutes } from "./script.routes";
